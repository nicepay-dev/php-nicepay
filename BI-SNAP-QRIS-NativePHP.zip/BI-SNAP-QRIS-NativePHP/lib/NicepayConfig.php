<?php
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2023 NICE IT&T
 *
 *
 * This config file may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 07.02.2023
 *
 * 07.02.2023 Update Log
 *
 * ____________________________________________________________
 */

// Please set the following
define("X_CLIENT_KEY",              "TNICEQR081");                                                 				 // Merchant ID
define("NICEPAY_DBPROCESS_URL",     "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp");                // Merchant's notification handler URL

/* TIMEOUT - Define as needed (in seconds) */
define( "NICEPAY_TIMEOUT_CONNECT", 15 );
define( "NICEPAY_TIMEOUT_READ", 25 );

// Please do not change
define("NICEPAY_PROGRAM",           "NicepayLite");
define("NICEPAY_VERSION",           "1.11");
define("NICEPAY_BUILDDATE",         "20160309");

// FOR DEV
define("NICEPAY_REQ_ACCESS_TOKEN_URL",  "https://dev.nicepay.co.id/nicepay/v1.0/access-token/b2b");             // Generate Access Token URL
define("NICEPAY_REGIST_QR_URL",   "https://dev.nicepay.co.id/nicepay/api/v1.0/qr/qr-mpm-generate");       	    // REGISTER QR (QRIS) URL
define("NICEPAY_CHECK_STATUS_QR_URL",   "https://dev.nicepay.co.id/nicepay/api/v1.0/qr/qr-mpm-query");       	// STATUS QR (QRIS) URL
define("NICEPAY_REFUND_QR_URL",   "https://dev.nicepay.co.id/nicepay/api/v1.0/qr/qr-mpm-refund");       	    // REFUND QR (QRIS) URL

// PRIVATE KEY
define("NICEPAY_PRIVATE_KEY",  <<<EOD
-----BEGIN RSA PRIVATE KEY-----
MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==
-----END RSA PRIVATE KEY-----
EOD);

// BASEURL
define("base_url", "http://localhost/BI-SNAP-QRIS-NativePHP/");

// FORM
define("form_url_regist", "http://localhost/BI-SNAP-QRIS-NativePHP/registQris.php");
define("form_url_status", "http://localhost/BI-SNAP-QRIS-NativePHP/checkStatusQris.php");
define("form_url_refund", "http://localhost/BI-SNAP-QRIS-NativePHP/refundQris.php");

define("NICEPAY_READ_TIMEOUT_ERR",  "10200");

/* LOG LEVEL */
define("NICEPAY_LOG_CRITICAL", 1);
define("NICEPAY_LOG_ERROR", 2);
define("NICEPAY_LOG_NOTICE", 3);
define("NICEPAY_LOG_INFO", 5);
define("NICEPAY_LOG_DEBUG", 7);