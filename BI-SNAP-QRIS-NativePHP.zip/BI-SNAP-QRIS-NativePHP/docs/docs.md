# API Documentation

## Configuration :

- `X_CLIENT_KEY => lib/NicepayConfig.php`
- `NICEPAY_REQ_ACCESS_TOKEN_URL => lib/NicepayConfig.php`
- `NICEPAY_GENERATE_QR_URL => lib/NicepayConfig.php`
- `NICEPAY_PRIVATE_KEY => lib/NicepayConfig.php`

## Endpoints :

List of available endpoints:

- `POST /BI-SNAP-QRIS-NativePHP/requestTokenRegist.php`
- `POST /BI-SNAP-QRIS-NativePHP/requestTokenCheckStatus.php`
- `POST /BI-SNAP-QRIS-NativePHP/requestTokenRefund.php`

&nbsp;

## 1. POST /BI-SNAP-QRIS-NativePHP/requestTokenRegist.php
## 2. POST /BI-SNAP-QRIS-NativePHP/requestTokenCheckStatus.php
## 3. POST /BI-SNAP-QRIS-NativePHP/requestTokenRefund.php

Request:

- body:

```json
{
  "grantType": "client_credentials",
  "additionalInfo": {

  }
}
```

_Response (Successful)_

```json
{
  "responseCode": "2007300",
  "responseMessage": "Successful",
  "accessToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJJT05QQVlURVNUIiwiaXNzIjoiTklDRVBBWSIsIm5hbWUiOiJCQkJBIiwiZXhwIjoiMjAyMy0wMi0wN1QwNDoxODoxM1oifQ==.IhwnC5Jip2WDs70EP2LnS3dGBd4rXwX1VU0JQEPeBrg=",
  "tokenType": "Bearer",
  "expiresIn": "900"
}
```

&nbsp;

## 2. POST /BI-SNAP-QRIS-NativePHP/registQris.php

Request:

- body:

```json
{
  "mitraCd": "QSHP"
}
```

_Response (Successful)_

```json
{
  "partnerReferenceNo": "ncpy20221017161458",
  "amount": {
      "value": "10000.00",
      "currency": "IDR"
  },
  "merchantId": "TNICEQR081",
  "storeId": "NicepayStoreID1",
  "additionalInfo": {
      "goodsNm": "John Doe",
      "billingNm": "John Doe",
      "billingPhone": "082111111111",
      "billingEmail": "merchant@gmail.com",
      "billingCity": "Jakarta",
      "billingState": "DKI Jakarta",
      "billingPostCd": "12345",
      "billingCountry": "Indonesia",
      "callBackUrl": "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp",
      "dbProcessUrl": "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp",
      "mitraCd": "QSHP",
      "cartData": "{\"count\":\"1\",\"item\":[{\"img_url\":\"http://www.jamgora.com/media/avatar/noimage.png\",\"goods_detail\":\"BB12345678\",\"goods_name\":\"Pasar Modern\",\"goods_amt\":\"10000\",\"goods_quantity\":\"1\"}]}"
  }
}
```

&nbsp;
