# API Documentation

## Configuration :

- `X_CLIENT_KEY => lib/NicepayConfig.php`
- `NICEPAY_REQ_ACCESS_TOKEN_URL => lib/NicepayConfig.php`
- `NICEPAY_GENERATE_DISBURSMEN_URL => lib/NicepayConfig.php`
- `NICEPAY_PRIVATE_KEY => lib/NicepayConfig.php`

## Endpoints :

List of available endpoints:

- `POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenRegist.php`
- `POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenApprove.php`
- `POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenReject.php`
- `POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenInquiry.php`
- `POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenCancel.php`
- `POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenBalance.php`

&nbsp;

## 1. POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenRegist.php
## 2. POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenApprove.php
## 3. POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenReject.php
## 4. POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenInquiry.php
## 5. POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenCancel.php
## 6. POST /BI-SNAP-DISBURSMENT-NativePHP/requestTokenBalance.php

Request:

- body:

```json
{
  "grantType": "client_credentials",
  "additionalInfo": {

  }
}
```

_Response (Successful)_

```json
{
  "responseCode": "2007300",
  "responseMessage": "Successful",
  "accessToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJJT05QQVlURVNUIiwiaXNzIjoiTklDRVBBWSIsIm5hbWUiOiJCQkJBIiwiZXhwIjoiMjAyMy0wMi0wN1QwNDoxODoxM1oifQ==.IhwnC5Jip2WDs70EP2LnS3dGBd4rXwX1VU0JQEPeBrg=",
  "tokenType": "Bearer",
  "expiresIn": "900"
}
```

&nbsp;
