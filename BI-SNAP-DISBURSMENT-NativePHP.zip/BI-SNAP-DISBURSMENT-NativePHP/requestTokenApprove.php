<?php
session_start();

// Include Config File
include_once "lib/NicepayConfig.php";

$X_CLIENT_KEY = X_CLIENT_KEY;
$requestToken = NICEPAY_REQ_ACCESS_TOKEN_URL;
date_default_timezone_set('Asia/Jakarta');
$X_TIMESTAMP = date('c');
$stringToSign = $X_CLIENT_KEY."|".$X_TIMESTAMP;

// Start encrypt data

$private_key = NICEPAY_PRIVATE_KEY;
$binary_signature = "";

$algo = "SHA256";
openssl_sign($stringToSign, $binary_signature, $private_key, $algo);

// End encrypt

$jsonData = array(
    "grantType" => "client_credentials"
);

$jsonDataEncode = json_encode($jsonData);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $requestToken);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncode);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'X-SIGNATURE: '.base64_encode($binary_signature),
    'X-CLIENT-KEY: '.$X_CLIENT_KEY,
    'X-TIMESTAMP: '.$X_TIMESTAMP
));

$output = curl_exec($ch);
$data = json_decode($output);
$accessToken = $data->accessToken;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <title>Request Access Token</title>

    <!-- CSS -->
	<link rel='stylesheet' href='index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Images -->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
    <link rel="icon" href="favicon.ico" type="image/x-icon" />

    <style>
        input[type="text"],
        input[type="number"],select {
            font-size:16px;
            padding:10px 10px 10px 5px;
            display:block;
            width:100%;
            border:none;
            border-bottom:1px solid #34CACA;
            text-transform: none;
        }

        .label{
            width: 100%;position: relative;top: 0px;display: block;user-select: none;
        }
        
        .form_hide{
            display: none;
        }
    </style>
</head>

<body>

    <!-- FORM REGIST ACCESS TOKEN -->
    <div id="regist-form" class="form-style-8">
        <h2>
            <img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">Access Token & Approve Disbursment
        </h2>
        <form action="<?php echo form_url_approve ;?>" method="post">
            <div class="group">
                <label class="label">Access Token</label>
                <input readonly type="text" name="accessToken" id="accessToken" value="<?php echo $data->accessToken; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group">
                <label class="label">Response Message</label>
                <input readonly type="text" name="responseMessage" id="responseMessage" value="<?php echo $data->responseMessage; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group">
                <label class="label">Expires Token</label>
                <input readonly type="text" name="expiresIn" id="expiresIn" value="<?php echo $data->expiresIn; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <input type="submit" value="Approve Disbursment" />
            <a href="<?php echo base_url ;?>"><input type="button" value="back" /></a>
        </form>
    </div>

    <script type="text/javascript" src="http://code.jquery.com/jquery-1.5.1.min.js?ver=3.5"></script>
    <script type="text/javascript" src="index.js"></script>
</body>
</html>