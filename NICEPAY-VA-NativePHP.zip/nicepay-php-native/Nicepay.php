<?

require_once './Nicepay/Snap.php';

class Nicepay {
    public static $Snap;

    public static function init() {
        // self::$Snap = new Snap();
    }
}

Nicepay::init();

