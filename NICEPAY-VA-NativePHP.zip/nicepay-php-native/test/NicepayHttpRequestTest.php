<?php
namespace test;


use Nicepay\common\HttpRequest;
use PHPUnit\Framework\TestCase;

use Exception;

require_once 'TestConst.php';

$headers = [
    'Content-Type: application/json',
    'X-TIMESTAMP: 2023-02-27T09:46:46+07:00',
    'X-CLIENT-KEY: IONPAYTEST',
    'X-SIGNATURE: VLeH5rgbswI9iZh/zSvhS7ugco/hculdAxr4yqGawgMhsmRWHEswZM1S4yBoKXBaRwP2DWsLgDDlrzjPguQ77cyfnfx1hedb0lvVO4TIfAFdOvxmz8IiH2shysabnQ7fEW6F0o59TDe/tZpLDuSdRz8WCXcfnWfDlvhqXLO7OSM='
];
$body = [
    'grantType' => 'client_credentials',
    'additionalInfo' => [],
];
$requestUrl = 'https://dev.nicepay.co.id/nicepay/v1.0/access-token/b2b';


class NicepayHttpRequestTest
{
    public function __construct()
    {
        // No initialization required for constructor
    }

    public function testStart()
    {
        echo "able to start test\n";
        return true;
    }

    public function testHttpRequest()
    {
        $httpRequest = new HttpRequest();
        global $headers, $requestUrl, $body;

        $method = "POST";
        try {
            $response = $httpRequest->request($headers, $requestUrl, $body, $method, false, null);
            echo "able to http request\n";
            if ($response['responseCode'] === '2007300' && $response['responseMessage'] === 'Successful') {
                echo "Test passed.\n";
            } else {
                echo "Test failed.\n";
            }
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage() . "\n";
        }
    }

    public function testHttpRequestWithString()
    {
        $httpRequest = new HttpRequest();
        global $headers, $requestUrl, $body;

        try {
            $response = $httpRequest->request($headers, $requestUrl, json_encode($body), "POST", false, null);
            echo "able to http request with string\n";
            if ($response['responseCode'] === '2007300' && $response['responseMessage'] === 'Successful') {
                echo "Test passed.\n";
            } else {
                echo "Test failed.\n";
            }
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage() . "\n";
        }
    }

    public function testHttpRequestWithWrongStringFormat()
    {
        $httpRequest = new HttpRequest();
        global $headers, $requestUrl, $wrongExample;

        try {
            $httpRequest->request($headers, $requestUrl, $wrongExample, "POST", false, null);
        } catch (Exception $e) {
            echo "not able to http request with wrong string format\n";
            if (is_string($e->getMessage())) {
                echo "Test passed.\n";
            } else {
                echo "Test failed.\n";
            }
        }
    }

    public function testTimeout()
    {
        $httpRequest = new HttpRequest();
        global $headers, $body;

        try {
            $httpRequest->request($headers, "https://httpstat.us/503?sleep=2500", $body, "POST", false, null);
        } catch (Exception $e) {
            if ($e->getCode() === CURLE_OPERATION_TIMEOUTED) {
                echo "should timeout after 7 seconds\n";
                echo "Test passed.\n";
            } else {
                echo 'Error: ' . $e->getMessage() . "\n";
                echo "Test failed.\n";
            }
        }
    }

    public function testErrorNotFromRequest()
    {
        $httpRequest = new HttpRequest();

        try {
            $httpRequest->request([], "", [], "POST", false, null);
        } catch (Exception $e) {
            echo "able to get error not from request\n";
            if (is_string($e->getMessage())) {
                echo "Test passed.\n";
            } else {
                echo "Test failed.\n";
            }
        }
    }

    

}

