<?php

namespace test;

class TestConst {

    public static string $CLIENT_SECRET = "";
    public static string $KEY_OLD_FORMAT = '';
    public static string $IMID_TEST = "";
    public static string $MERCHANT_KEY = '';

    public static string $PRIVATE_KEY_STRING =  "";
    
}
