<?php 

namespace Nicepay\service\snap;

use Nicepay\data\model\VirtualAccount;
use Nicepay\data\response\NicepayResponse;
use Nicepay\common\NICEPay;
use Nicepay\utils\NicepayCons;

class SnapVAService {

    public function generateVA(VirtualAccount $requestBody, string $accessToken, NICEPay $config):NicepayResponse {
        $snap = new Snap($config);
        return $snap->requestSnapTransaction($requestBody, NicepayCons::getCreateVASnapEndpoint(), $accessToken, "POST");
    }

    
}