<?php

namespace Nicepay\common;

class HttpRequest
{
    public function __construct()
    {
        // No initialization required for cURL in constructor
    }

    /**
     * Wrapper of cURL to do API request to Nicepay API
     * @param array $headers
     * @param string $requestUrl
     * @param mixed $requestBody
     * @return mixed API response, or exception during request
     */
        public function request($headers, $requestUrl, $requestBody, $method, $isRetryFlag, $retryLimit)
    {

        $attempt = 0;
        $timeoutErrorCodes = [CURLE_OPERATION_TIMEOUTED, CURLE_COULDNT_CONNECT];

        do {
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, $requestUrl);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
            if (in_array(strtoupper($method), ['POST', 'PUT', 'PATCH', 'DELETE'])) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);
            }
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15); 

            $response = curl_exec($ch);

            // Check if cURL request failed (e.g., timeout)
            if (curl_errno($ch)) {
                $errorCode = curl_errno($ch);
                $errorMsg = curl_error($ch);
                curl_close($ch);

                // Check if the error is a timeout and retry is enabled
                if ($isRetryFlag && in_array($errorCode, $timeoutErrorCodes) && $attempt < $retryLimit) {
                    $attempt++;
                    sleep(1); // wait before retry
                    continue;
                }

                // If it's not a retryable error, throw an exception
                throw new NicepayError($errorMsg);
            }

            // Get the HTTP response code
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

            curl_close($ch);

            // If the request was successful (HTTP 2xx)
            if ($httpCode >= 200 && $httpCode < 300) {
                // Validate and parse JSON response
                $jsonResponse = json_decode($response, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    return $jsonResponse;
                } else {
                    // If the JSON response cannot be decoded, throw an error
                    throw new NicepayError("Failed to parse response as JSON: " . json_last_error_msg() . "\nResponse: " . $response);
                }
            }

            // If the HTTP code is 504 (Gateway Timeout), retry the request if retry is enabled
            if ($isRetryFlag && $httpCode === 504 && $attempt < $retryLimit) {
                $attempt++;
                sleep(1); 
                continue;
            }

            // Handle non-retryable HTTP errors
            $responseBody = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new NicepayError("Failed to parse response as JSON with message: " . json_last_error_msg() . "\nResponse: " . $response);
            }

            throw new NicepayError("HTTP Error $httpCode: " . print_r($responseBody, true));
        } while ($isRetryFlag && $attempt <= $retryLimit);

        // If retries are exhausted
        return $response;
    }
}
