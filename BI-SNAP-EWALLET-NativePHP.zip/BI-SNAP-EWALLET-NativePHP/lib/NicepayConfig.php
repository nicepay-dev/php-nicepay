<?php
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2023 NICE IT&T
 *
 *
 * This config file may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 07.02.2023
 *
 * 07.02.2023 Update Log
 *
 * ____________________________________________________________
 */

// Please set the following
define("X_CLIENT_KEY",              "TNICEEW051");                                                 				 // Merchant ID
define("NICEPAY_DBPROCESS_URL",     "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp");                // Merchant's notification handler URL

/* TIMEOUT - Define as needed (in seconds) */
define( "NICEPAY_TIMEOUT_CONNECT", 15 );
define( "NICEPAY_TIMEOUT_READ", 25 );

// Please do not change
define("NICEPAY_PROGRAM",           "NicepayLite");
define("NICEPAY_VERSION",           "1.11");
define("NICEPAY_BUILDDATE",         "20160309");

// FOR DEV
define("NICEPAY_REQ_ACCESS_TOKEN_URL",  "https://dev.nicepay.co.id/nicepay/v1.0/access-token/b2b");                     // Generate Access Token URL
define("NICEPAY_PAYMENT_EWALLET_URL",   "https://dev.nicepay.co.id/nicepay/api/v1.0/debit/payment-host-to-host");       // Payment Ewallet URL
define("NICEPAY_CHECK_STATUS_URL",   "https://dev.nicepay.co.id/nicepay/api/v1.0/debit/status");       	                // Check Status Ewallet URL
define("NICEPAY_REFUND_URL",   "https://dev.nicepay.co.id/nicepay/api/v1.0/debit/refund");       	                    // Refund Ewallet URL

// PRIVATE KEY
define("NICEPAY_PRIVATE_KEY",  <<<EOD
-----BEGIN RSA PRIVATE KEY-----
MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==
-----END RSA PRIVATE KEY-----
EOD);

// BASEURL
define("base_url", "http://localhost/BI-SNAP-EWALLET-NativePHP/");

// FORM
define("form_url_payment_ovo", "http://localhost/BI-SNAP-EWALLET-NativePHP/paymentEwalletOvoe.php");
define("form_url_status_ovo", "http://localhost/BI-SNAP-EWALLET-NativePHP/checkStatusEwalletOvoe.php");
define("form_url_refund_ovo", "http://localhost/BI-SNAP-EWALLET-NativePHP/refundEwalletOvoe.php");

define("form_url_payment_dana", "http://localhost/BI-SNAP-EWALLET-NativePHP/paymentEwalletDana.php");
define("form_url_status_dana", "http://localhost/BI-SNAP-EWALLET-NativePHP/checkStatusEwalletDana.php");
define("form_url_refund_dana", "http://localhost/BI-SNAP-EWALLET-NativePHP/refundEwalletDana.php");

define("form_url_payment_linkaja", "http://localhost/BI-SNAP-EWALLET-NativePHP/paymentEwalletLinkaja.php");
define("form_url_status_linkaja", "http://localhost/BI-SNAP-EWALLET-NativePHP/checkStatusEwalletLinkaja.php");
define("form_url_refund_linkaja", "http://localhost/BI-SNAP-EWALLET-NativePHP/refundEwalletLinkaja.php");

define("form_url_payment_shopee", "http://localhost/BI-SNAP-EWALLET-NativePHP/paymentEwalletShopee.php");
define("form_url_status_shopee", "http://localhost/BI-SNAP-EWALLET-NativePHP/checkStatusEwalletShopee.php");
define("form_url_refund_shopee", "http://localhost/BI-SNAP-EWALLET-NativePHP/refundEwalletShopee.php");

define("NICEPAY_READ_TIMEOUT_ERR",  "10200");

/* LOG LEVEL */
define("NICEPAY_LOG_CRITICAL", 1);
define("NICEPAY_LOG_ERROR", 2);
define("NICEPAY_LOG_NOTICE", 3);
define("NICEPAY_LOG_INFO", 5);
define("NICEPAY_LOG_DEBUG", 7);