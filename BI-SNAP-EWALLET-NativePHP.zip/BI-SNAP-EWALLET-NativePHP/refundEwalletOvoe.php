<?php
session_start();

// Include Config File
include_once "lib/NicepayConfig.php";

$X_CLIENT_KEY = X_CLIENT_KEY;

date_default_timezone_set('Asia/Jakarta');
$X_TIMESTAMP = date('c');

$authorization = "Bearer ".$_POST['accessToken'];
$channel = X_CLIENT_KEY.rand();
$external = "EXT".rand();
$partner = X_CLIENT_KEY.rand();
$secretClient = "1af9014925cab04606b2e77a7536cb0d5c51353924a966e503953e010234108a";
$body = '{"merchantId": "TNICEEW051","subMerchantId": "","originalPartnerReferenceNo": "RefnoTrx20220322235959","originalReferenceNo": "TNICEEW05105202302221538023114","partnerRefundNo": "RefnoTrx20220322235959","refundAmount":{"value": "10000.00","currency": "IDR"},"externalStoreId": "","reason": "Customer Refund","additionalInfo": {"refundType": "1"}}';
$hashBody = strtolower(hash("SHA256", $body));

$stirgSign = "POST:/api/v1.0/debit/refund:".$_POST['accessToken'].":".$hashBody.":".$X_TIMESTAMP;
$bodyHasing = hash_hmac("sha512", $stirgSign, $secretClient, true);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, NICEPAY_REFUND_URL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'X-SIGNATURE: '.base64_encode($bodyHasing),
    'X-CLIENT-KEY: '.$X_CLIENT_KEY,
    'X-TIMESTAMP: '.$X_TIMESTAMP,
    'Authorization: '.$authorization,
    'CHANNEL-ID: '.$channel,
    'X-EXTERNAL-ID: '.$external,
    'X-PARTNER-ID: '.$X_CLIENT_KEY
));

$output = curl_exec($ch);
$data = json_decode($output);

$resultCd = "200";

$responseCode = $data->responseCode;
$responseMessage = $data->responseMessage;

if(stripos($responseCode, $resultCd) !== FALSE){
    $originalPartnerReferenceNo = $data->originalPartnerReferenceNo;
    $originalReferenceNo = $data->originalReferenceNo;
    $currency = $data->refundAmount->currency;
    $value = $data->refundAmount->value;
    $refundNo = $data->refundNo;
    $partnerRefundNo = $data->partnerRefundNo;
} else {
    $responseCode = $data->responseCode;
    $responseMessage = $data->responseMessage;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <meta http-equiv="refresh" content="900; url=<?php echo base_url ;?>">
    <title>Result - Refund OVO</title>

    <!-- CSS -->
	<link rel='stylesheet' href='index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Images -->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
    <link rel="icon" href="favicon.ico" type="image/x-icon" />

    <style>
        input[type="text"],
        input[type="number"],select {
            font-size:16px;
            padding:10px 10px 10px 5px;
            display:block;
            width:100%;
            border:none;
            border-bottom:1px solid #34CACA;
            text-transform: none;
        }
        .label{
            width: 100%;position: relative;top: 0px;display: block;user-select: none;
        }
    </style>
</head>

<body>
    <div class="form-style-8">
        <h2>
            <img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">Result Refund Ewallet - OVO
        </h2>
        <?php if(stripos($responseCode, $resultCd) !== FALSE) { ?>
            <div class="group mitra-cd">
                <label class="label">Response Code</label>
                <input readonly type="text" name="responseCode" id="responseCode" value="<?php echo $responseCode; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group mitra-cd">
                <label class="label">Response Message</label>
                <input readonly type="text" name="responseMessage" id="responseMessage" value="<?php echo $responseMessage; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group">
                <label class="label">Original Partner ReferenceNo</label>
                <input readonly type="text" name="originalPartnerReferenceNo" id="originalPartnerReferenceNo" value="<?php echo $originalPartnerReferenceNo; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group">
                <label class="label">Original ReferenceNo</label>
                <input readonly type="text" name="originalReferenceNo" id="originalReferenceNo" value="<?php echo $originalReferenceNo; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group">
                <label class="label">Currency</label>
                <input readonly type="text" name="currency" id="currency" value="<?php echo $currency; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group">
                <label class="label">Value</label>
                <input readonly type="text" name="value" id="value" value="<?php echo $value; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group">
                <label class="label">Refund No</label>
                <input readonly type="text" name="refundNo" id="refundNo" value="<?php echo $refundNo; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group">
                <label class="label">Partner Refund No</label>
                <input readonly type="text" name="partnerRefundNo" id="partnerRefundNo" value="<?php echo $partnerRefundNo; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
        <?php } else { ?>
            <div class="group mitra-cd">
                <label class="label">Response Code</label>
                <input readonly type="text" name="responseCode" id="responseCode" value="<?php echo $responseCode; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
            <div class="group mitra-cd">
                <label class="label">Response Message</label>
                <input readonly type="text" name="responseMessage" id="responseMessage" value="<?php echo $responseMessage; ?>"/>
                <span class="highlight"></span>
                <span class="bar"></span>
            </div>
        <?php } ?>
        
        <a href="<?php echo base_url ;?>"><input type="button" value="back" /></a>
    </div>
</body>
</html>