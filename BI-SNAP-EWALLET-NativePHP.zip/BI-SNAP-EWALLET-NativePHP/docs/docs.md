# API Documentation

## Configuration :

- `X_CLIENT_KEY => lib/NicepayConfig.php`
- `NICEPAY_REQ_ACCESS_TOKEN_URL => lib/NicepayConfig.php`
- `NICEPAY_GENERATE_EWALLET_URL => lib/NicepayConfig.php`
- `NICEPAY_PRIVATE_KEY => lib/NicepayConfig.php`

## Endpoints :

List of available endpoints:

- `POST /BI-SNAP-EWALLET-NativePHP/requestTokenOvoe.php`
- `POST /BI-SNAP-EWALLET-NativePHP/requestTokenDana.php`
- `POST /BI-SNAP-EWALLET-NativePHP/requestTokenLinkaja.php`
- `POST /BI-SNAP-EWALLET-NativePHP/requestTokenShopee.php`

&nbsp;

## 1. POST /BI-SNAP-EWALLET-NativePHP/requestTokenOvoe.php
## 1. POST /BI-SNAP-EWALLET-NativePHP/requestTokenDana.php
## 1. POST /BI-SNAP-EWALLET-NativePHP/requestTokenLinkaja.php
## 1. POST /BI-SNAP-EWALLET-NativePHP/requestTokenShopee.php

Request:

- body:

```json
{
  "grantType": "client_credentials",
  "additionalInfo": {

  }
}
```

_Response (Successful)_

```json
{
  "responseCode": "2007300",
  "responseMessage": "Successful",
  "accessToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJJT05QQVlURVNUIiwiaXNzIjoiTklDRVBBWSIsIm5hbWUiOiJCQkJBIiwiZXhwIjoiMjAyMy0wMi0wN1QwNDoxODoxM1oifQ==.IhwnC5Jip2WDs70EP2LnS3dGBd4rXwX1VU0JQEPeBrg=",
  "tokenType": "Bearer",
  "expiresIn": "900"
}
```

&nbsp;
